# setup.py, but with setup.cfg
# v3.0

from setuptools import setup # type: ignore

setup()