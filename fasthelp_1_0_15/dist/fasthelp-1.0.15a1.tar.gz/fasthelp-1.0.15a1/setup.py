# setup.py, but with pyproject.toml and setup.ini

from setuptools import setup # type: ignore

setup()