from .all_is_os import OS
from .gpuinfo import get_gpu_info

__all__ = ["OS", "get_gpu_info"]