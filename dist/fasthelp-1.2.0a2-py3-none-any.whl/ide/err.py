class RemovalError(ModuleNotFoundError):
    pass

class err:
    def err():
        raise RemovalError("This class has been removed.")