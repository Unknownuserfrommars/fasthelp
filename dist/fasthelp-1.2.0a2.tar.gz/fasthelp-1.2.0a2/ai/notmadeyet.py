class nmy:
    def err():
        print("Not Made Yet")