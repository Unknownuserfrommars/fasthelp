# setup.py, but with pyproject.toml and setup.cfg

from setuptools import setup # type: ignore

setup()